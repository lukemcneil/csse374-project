
public class Coffee {

	String name;
	String[] conds;
	
	public Coffee(String name, String[] condds) {
		this.name = name;
		this.conds = condds;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String[] getConds() {
		return this.conds;
	}
	
}
